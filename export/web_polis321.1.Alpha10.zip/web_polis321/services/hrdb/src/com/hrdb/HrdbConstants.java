
package com.hrdb;



/**
 *  Query names for service "hrdb"
 *  11/08/2555 19:08:43
 * 
 */
public class HrdbConstants {

    public final static String getDepartmentByIdQueryName = "getDepartmentById";

}
