
package com.oracdgs9db.data;



/**
 *  oracdgs9DB.DataReg1
 *  10/26/2555 14:17:40
 * 
 */
public class DataReg1 {

    private DataReg1Id id;

    public DataReg1Id getId() {
        return id;
    }

    public void setId(DataReg1Id id) {
        this.id = id;
    }

}
