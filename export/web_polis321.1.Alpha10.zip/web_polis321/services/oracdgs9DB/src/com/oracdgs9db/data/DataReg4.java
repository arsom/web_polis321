
package com.oracdgs9db.data;



/**
 *  oracdgs9DB.DataReg4
 *  10/26/2555 14:17:40
 * 
 */
public class DataReg4 {

    private DataReg4Id id;

    public DataReg4Id getId() {
        return id;
    }

    public void setId(DataReg4Id id) {
        this.id = id;
    }

}
