
package com.oracdgs9db;



/**
 *  Query names for service "oracdgs9DB"
 *  11/08/2555 19:08:44
 * 
 */
public class Oracdgs9DBConstants {

    public final static String selDatMatchSourceByCodeQueryName = "selDatMatchSourceByCode";
    public final static String getDatSuitByIdQueryName = "getDatSuitById";
    public final static String selDatGroupCQueryName = "selDatGroupC";
    public final static String selStartAppQueryName = "selStartApp";

}
