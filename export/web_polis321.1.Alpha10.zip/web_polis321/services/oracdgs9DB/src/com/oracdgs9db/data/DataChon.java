
package com.oracdgs9db.data;



/**
 *  oracdgs9DB.DataChon
 *  10/26/2555 14:17:40
 * 
 */
public class DataChon {

    private DataChonId id;

    public DataChonId getId() {
        return id;
    }

    public void setId(DataChonId id) {
        this.id = id;
    }

}
