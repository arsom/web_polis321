
package com.oracdgs9db.data;



/**
 *  oracdgs9DB.DataReg3
 *  10/26/2555 14:17:40
 * 
 */
public class DataReg3 {

    private DataReg3Id id;

    public DataReg3Id getId() {
        return id;
    }

    public void setId(DataReg3Id id) {
        this.id = id;
    }

}
