
package com.oracdgs9db.data;



/**
 *  oracdgs9DB.DataReg6
 *  10/26/2555 14:17:40
 * 
 */
public class DataReg6 {

    private DataReg6Id id;

    public DataReg6Id getId() {
        return id;
    }

    public void setId(DataReg6Id id) {
        this.id = id;
    }

}
