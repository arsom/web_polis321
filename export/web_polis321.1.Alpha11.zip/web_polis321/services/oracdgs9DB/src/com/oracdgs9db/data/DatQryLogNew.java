
package com.oracdgs9db.data;



/**
 *  oracdgs9DB.DatQryLogNew
 *  10/26/2555 14:17:40
 * 
 */
public class DatQryLogNew {

    private DatQryLogNewId id;

    public DatQryLogNewId getId() {
        return id;
    }

    public void setId(DatQryLogNewId id) {
        this.id = id;
    }

}
