
package com.oracdgs9db.data;



/**
 *  oracdgs9DB.DatCountLogmoi
 *  10/26/2555 14:17:40
 * 
 */
public class DatCountLogmoi {

    private DatCountLogmoiId id;

    public DatCountLogmoiId getId() {
        return id;
    }

    public void setId(DatCountLogmoiId id) {
        this.id = id;
    }

}
