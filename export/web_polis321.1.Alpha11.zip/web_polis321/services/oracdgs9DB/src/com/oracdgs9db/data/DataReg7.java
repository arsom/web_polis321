
package com.oracdgs9db.data;



/**
 *  oracdgs9DB.DataReg7
 *  10/26/2555 14:17:40
 * 
 */
public class DataReg7 {

    private DataReg7Id id;

    public DataReg7Id getId() {
        return id;
    }

    public void setId(DataReg7Id id) {
        this.id = id;
    }

}
