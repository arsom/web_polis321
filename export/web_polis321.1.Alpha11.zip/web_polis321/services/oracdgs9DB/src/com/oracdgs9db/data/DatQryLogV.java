
package com.oracdgs9db.data;



/**
 *  oracdgs9DB.DatQryLogV
 *  10/26/2555 14:17:40
 * 
 */
public class DatQryLogV {

    private DatQryLogVId id;

    public DatQryLogVId getId() {
        return id;
    }

    public void setId(DatQryLogVId id) {
        this.id = id;
    }

}
