
package com.oracdgs9db.data;



/**
 *  oracdgs9DB.DataReg5
 *  10/26/2555 14:17:40
 * 
 */
public class DataReg5 {

    private DataReg5Id id;

    public DataReg5Id getId() {
        return id;
    }

    public void setId(DataReg5Id id) {
        this.id = id;
    }

}
